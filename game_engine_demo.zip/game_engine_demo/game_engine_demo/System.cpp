#include "System.h"

System::System()
{
	// any base module construction happens here
}

System::System(const System&)
{

}

System::~System()
{
}

bool System::Initialize()
{
	int screenWidth, screenHeight;
	bool result = true;

	screenWidth = screenHeight = 0;

	InitialiseWindow(screenWidth, screenHeight);

	return result;
}

void System::Shutdown()
{
	ShutdownWindow();
}

void System::Run()
{
	MSG msg;
	bool done, result;

	ZeroMemory(&msg, sizeof(MSG));

	done = false;
	while (!done)
	{
		if (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}

		if (msg.message == WM_QUIT)
		{
			done = true;
		}
		else {
			result = Frame();
			if (!result)
				done = true;
		}
	}
}

bool System::Frame()
{
	return true;
}

void System::InitialiseWindow(int& screenWidth, int& screenHeight)
{
	//build the window to draw
	WNDCLASSEX wc; // WNDCLASSEX contains a lot of info to setup the window
	DEVMODE dmScreenSettings; // DEVMODE contains info about the display device
	int posX, posY;

	// get an external pointer to the instance of the System object
	ApplicationHandle = this;

	// get a handle to the instance of the application
	hInstance = GetModuleHandle(NULL);

	applicationName = L"Generic Engine";

	wc.style = CS_HREDRAW | CS_VREDRAW | CS_OWNDC;
	wc.lpfnWndProc = WndProc;
	wc.cbClsExtra = 0;
	wc.cbWndExtra = 0;
	wc.hInstance = hInstance;
	wc.hIcon = LoadIcon(NULL, IDI_WINLOGO);
	wc.hIconSm = wc.hIcon;
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);
	wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
	wc.lpszClassName = applicationName;
	wc.lpszMenuName = NULL;
	wc.cbSize = sizeof(WNDCLASSEX);

	if (!RegisterClassEx(&wc)) {
		MessageBox(NULL, L"Window Registration Failed", L"Error", MB_ICONEXCLAMATION | MB_OK);
	}

	screenWidth = 800;
	screenHeight = 600;

	posX = (GetSystemMetrics(SM_CXSCREEN) - screenWidth) / 2;
	posY = (GetSystemMetrics(SM_CYSCREEN) - screenHeight) / 2;

	hWnd = CreateWindowEx(WS_EX_CLIENTEDGE, applicationName, applicationName, 
		WS_OVERLAPPEDWINDOW, posX, posY, screenWidth, screenHeight, 
		NULL, NULL, hInstance, NULL);

	if (hWnd == NULL)
	{
		int error = GetLastError();
		MessageBox(NULL, L"Error creating window", L"Error", MB_ICONEXCLAMATION | MB_OK);
	}

	ShowWindow(hWnd, SW_SHOW);
	UpdateWindow(hWnd);
	SetForegroundWindow(hWnd);
	SetFocus(hWnd);

	ShowCursor(false);
}

void System::ShutdownWindow()
{
	ShowCursor(true);

	DestroyWindow(hWnd);
	hWnd = NULL;

	UnregisterClass(applicationName, hInstance);
	hInstance = NULL;

	ApplicationHandle = nullptr;
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT umessage, WPARAM wparam, LPARAM lparam)
{
	PAINTSTRUCT ps;
	HDC hdc;
	TCHAR greeting[] = _T("Hello World!");

	switch (umessage)
	{
		case WM_DESTROY:
		{
			PostQuitMessage(0);
			return 0;
		}
		case WM_CLOSE:
		{
			PostQuitMessage(0);
			return 0;
		}

		case WM_PAINT:
		{
			hdc = BeginPaint(hwnd, &ps);

			TextOut(hdc, 5, 5, greeting, _tcslen(greeting));

			EndPaint(hwnd, &ps);
			break;
		}
	}

	return DefWindowProc(hwnd, umessage, wparam, lparam);
}