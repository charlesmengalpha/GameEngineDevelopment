#pragma once

#define WIN32_LEAN_AND_MEAN

#include <Windows.h>
#include <tchar.h>

class System
{
public:
	System(); // constructor
	System(const System&); // copy constructor
	~System(); // deconstructor 

	bool Initialize();
	void Shutdown();
	void Run();


private:

	bool Frame();
	void InitialiseWindow(int&, int&);
	void ShutdownWindow();

	LPCWSTR applicationName;
	HINSTANCE hInstance;
	HWND hWnd;
};

static LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);

static System* ApplicationHandle = nullptr;